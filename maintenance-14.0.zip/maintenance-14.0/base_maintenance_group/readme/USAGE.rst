Assign any of the Maintenance groups ('User' or 'Equipment Manager' or
'Full Access') to the users, in order to enable the maintenance menus.

To do so, you need to:

#. Go on 'Settings' -> 'Users & Companies' -> 'Users'.
#. Create a new user or select an already existing one.
#. In the tab 'Access Rights', at the 'Application Accesses' paragraph,
   set a group in the 'Maintenance' category.
