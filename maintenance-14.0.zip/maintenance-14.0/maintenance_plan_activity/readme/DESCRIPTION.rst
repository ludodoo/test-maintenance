This module allows defining in the maintenance plan activities that will be created once the maintenance
requests are created as a consequence of the plan itself.

.. image:: /maintenance_plan_activity/static/description/maintenance_plan_activity.png
    :alt: Maintenance Planned Activities
