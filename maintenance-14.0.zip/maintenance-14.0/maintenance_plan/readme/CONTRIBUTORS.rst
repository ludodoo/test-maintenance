* Akim Juillerat <akim.juillerat@camptocamp.com>
* Matteo Mazzoni <matteo@appcademy.tech>
* David Alonso <david.alonso@solvos.es>
* Adrià Gil Sorribes <adria.gil@forgeflow.com>
* Jordi Ballester Alomar <jordi.ballester@forgeflow.com>
* Lois Rilo <lois.rilo@forgeflow.com>
