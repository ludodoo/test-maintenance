This module introduces a sequence to the maintenance equipment managed from the maintenance equipment category
