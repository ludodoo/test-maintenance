This module links maintenance equipment with supplier contracts.
To link an equipment go to the contract's form and add it to the Equipments
field.
