This module allows to indicate status of an equipment.
