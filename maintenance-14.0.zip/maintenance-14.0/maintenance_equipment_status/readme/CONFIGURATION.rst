To cotnfigure this module, you need to:

#. Maintenance > Configuration > Equipment Statuses

You can limit the usage of status to specific equipment categories.
