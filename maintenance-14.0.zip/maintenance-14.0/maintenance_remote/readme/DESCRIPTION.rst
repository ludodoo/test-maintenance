This module allows to show the remote on a maintenance request where the issue
was created. It is useful on requests related to IT.
