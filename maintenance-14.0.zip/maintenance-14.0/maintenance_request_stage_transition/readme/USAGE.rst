* Access `Maintenance > Configuration > Maintenance Stages`
* Define the possible next stages of every stage
* You can specify the color of the button if needed
* Refresh the page in order to show the new possible stages
* The stage widget will be blocked and the expected button will appear on the header.
