It allows to define the next stages of a stage and shows them on the header buttons.
