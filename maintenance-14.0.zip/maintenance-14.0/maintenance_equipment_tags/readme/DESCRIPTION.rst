Adds category tags to equipment
