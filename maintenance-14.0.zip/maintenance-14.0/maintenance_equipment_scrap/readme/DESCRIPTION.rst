This module improves the action of scrapping an equipment, sending a
message and automatically setting the scrap date when the action is performed.
