To let one user access the general settings section for the maintenance
configuration, you should assign the 'Equipments Manager' group to that user.

To do so, you need to:

#. Go on 'Settings' -> 'Users & Companies' -> 'Groups'.
#. Open the group 'Maintenance / Equipment Manager' form.
#. In the tab 'Users', add the user you want to give access to.
