To use this module, you need to:

#. Go to *Maintenance > Configuration > General Settings*.
