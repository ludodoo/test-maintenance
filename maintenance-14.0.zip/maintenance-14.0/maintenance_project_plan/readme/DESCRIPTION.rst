This module adds project and task fields to a Maintenance Plan, which will be automatically propagated to any maintenance request generated from a Plan.
