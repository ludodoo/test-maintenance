This addon allows to define a hierarchy of teams and teams show the related requests
